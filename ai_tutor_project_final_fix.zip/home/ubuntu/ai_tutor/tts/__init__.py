"""
__init__.py file for tts package.
Makes the package importable and exposes key classes.
"""
from .text_to_speech import TextToSpeech
from .tts_component import TTSComponent

__all__ = ['TextToSpeech', 'TTSComponent']
